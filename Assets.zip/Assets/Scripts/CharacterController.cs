using UnityEngine;
using TMPro;

public class CharacterController : MonoBehaviour
{
    [SerializeField][Range(0.5f, 10.0f)] private float Speed;
    [SerializeField] private int Counter;
    [SerializeField][Range(1, 100)] private int Health = 100;
    [SerializeField][Range(0.5f, 5.0f)] private float JumpForce;
    [SerializeField] private SpriteRenderer sr;
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private bool CanJump = true;
    [SerializeField] private TextMeshProUGUI ShowCounter;
    [SerializeField] private TextMeshProUGUI ShowHealth;
    [HideInInspector] public float DirectionX;

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        ShowCounter.text = $"Coin: {Counter}";
        ShowHealth.text = $"Health: {Health}";
    }

    void Update()
    {
        DirectionX = Input.GetAxis("Horizontal");

        Vector2 movement = new Vector2(DirectionX, 0);
        transform.Translate(movement * Speed * Time.deltaTime);
        if (DirectionX < 0)
        {
            sr.flipX = true;
        }
        else if (DirectionX > 0)
        {
            sr.flipX = false;
        }
        if (Health == 0)
        {
            Destroy(this.gameObject);
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (CanJump == true)
            {
                rb.AddForce(Vector2.up * JumpForce, ForceMode2D.Impulse);
                CanJump = false;
            }
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Coin")
        {
            Destroy(collision.gameObject);
            Counter++;
            ShowCounter.text = $"Coin: {Counter}";
        }
        if (collision.gameObject.tag == "Enemy")
        {
            Health = Health - 25;
            ShowHealth.text = $"Health: {Health}";
        }
        if (collision.gameObject.tag == "Ground")
        {
            CanJump = true;
        }
        if (collision.gameObject.tag == "Finish")
        {
            Destroy(this.gameObject);        }
    }
}
