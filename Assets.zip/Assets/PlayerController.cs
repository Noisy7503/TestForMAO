using UnityEngine;

public class PlayerMove : MonoBehaviour
{


    [HideInInspector] public Rigidbody _rb;
    [HideInInspector] public Vector3 _moveVector;
    [SerializeField][Range(0.1f, 7.0f)] private float _speed;
    void Start()
    {
        _rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        _moveVector.x = Input.GetAxis("Horizontal");
        _moveVector.z = Input.GetAxis("Vertical");
        _rb.MovePosition(_rb.position + _moveVector * _speed * Time.deltaTime);
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Enemy")
        {
            Debug.Log("You Lose!");
            Destroy(this.gameObject);
        }
    }
}
